<?php
$acao = $_POST['acao'] ?? '';

if ($acao === 'login') {
    $login = $_POST['login'] ?? '';
    $senha = $_POST['senha'] ?? '';
} else {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $idade = $_POST['idade'] ?? '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $acao === 'login' ? 'Login Realizado' : 'Dados do Cadastro'; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <?php if ($acao === 'login'): ?>
                <h1>Bem-vindo!</h1>
                <p><strong>Usuario:</strong> <?php echo htmlspecialchars($login); ?></p>
                <p>Login realizado com sucesso.</p>
            <?php else: ?>
                <h1>Cadastro Realizado</h1>
                <p><strong>Nome:</strong> <?php echo htmlspecialchars($nome); ?></p>
                <p><strong>E-mail:</strong> <?php echo htmlspecialchars($email); ?></p>
                <p><strong>Idade:</strong> <?php echo htmlspecialchars($idade); ?></p>
            <?php endif; ?>

            <div class="acoes">
                <a class="btn" href="cadastro.html">Novo cadastro</a>
                <a class="btn btn-secundario" href="index.html">Pagina inicial</a>
            </div>
        </div>
    </div>
</body>
</html>