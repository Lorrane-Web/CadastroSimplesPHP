document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const nomeInput = document.getElementById('nome');
    const emailInput = document.getElementById('email');
    const idadeInput = document.getElementById('idade');

    form.addEventListener('submit', function(event) {
        if (!validateForm()) {
            event.preventDefault();
        }
    });

    function validateForm() {
        if (nomeInput.value.trim() === '') {
            alert('Por favor, insira seu nome.');
            nomeInput.focus();
            return false;
        }

        if (emailInput.value.trim() === '') {
            alert('Por favor, insira seu e-mail.');
            emailInput.focus();
            return false;
        }

        if (!isValidEmail(emailInput.value.trim())) {
            alert('Por favor, insira um e-mail valido.');
            emailInput.focus();
            return false;
        }

        var idade = parseInt(idadeInput.value, 10);
        if (isNaN(idade) || idade < 1 || idade > 150) {
            alert('Por favor, insira uma idade valida (1-150).');
            idadeInput.focus();
            return false;
        }

        return true;
    }

    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});